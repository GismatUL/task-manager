<?php $__env->startSection('content'); ?>
    <div class="container mt-5">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-primary">Task Manager</h2>
            <a href="<?php echo e(route('tasks.create')); ?>" class="btn btn-success">
                <i class="fas fa-plus"></i> Add New Task
            </a>
        </div>
        <form method="GET" action="<?php echo e(route('tasks.index')); ?>" class="mb-4">
            <div class="row">
                <div class="col-md-4">
                    <select name="project_id" class="form-select" onchange="this.form.submit()">
                        <option value="">-- All Projects --</option>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($project->id); ?>" <?php echo e(request('project_id') == $project->id ? 'selected' : ''); ?>>
                                <?php echo e($project->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
        </form>

        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <div class="table-responsive">
            <table class="table table-striped table-hover">
                <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Task Name</th>
                    <th>Project</th>
                    <th>Priority</th>
                    <th>Actions</th>
                </tr>
                </thead>
                <tbody id="sortable">
                <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr data-id="<?php echo e($task->id); ?>" class="sortable-row">
                        <td><i class="fas fa-arrows-alt"></i></td>
                        <td><?php echo e($task->name); ?></td>
                        <td><?php echo e($task->project->name ?? 'N/A'); ?></td>
                        <td class="priority-value"><?php echo e($task->priority); ?></td>
                        <td>
                            <a href="<?php echo e(route('tasks.edit', $task->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fas fa-edit"></i> Edit
                            </a>
                            <form action="<?php echo e(route('tasks.destroy', $task->id)); ?>" method="POST" class="d-inline-block">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                    <i class="fas fa-trash"></i> Delete
                                </button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="text-center text-muted">No tasks available.</td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $(function () {
            $("#sortable").sortable({
                axis: "y",  // Only allow vertical dragging
                cursor: "grab",
                opacity: 0.7,
                placeholder: "sortable-placeholder",
                stop: function (event, ui) {
                    let order = [];
                    $("#sortable tr").each(function (index) {
                        let taskId = $(this).data("id");
                        order.push({ id: taskId, priority: index + 1 });
                        $(this).find(".priority-value").text(index + 1);
                    });

                    $.ajax({
                        url: "<?php echo e(route('tasks.updateOrder')); ?>",
                        type: "POST",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            order: order
                        },
                        success: function (response) {
                            console.log("Order updated successfully!", response);
                        },
                        error: function (xhr) {
                            console.error("Error updating order", xhr);
                        }
                    });
                }
            });
        });

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\task-manager\resources\views/tasks/index.blade.php ENDPATH**/ ?>